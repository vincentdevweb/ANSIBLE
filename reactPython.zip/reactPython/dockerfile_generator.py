import os
import yaml

class DockerfileGenerator:
    def __init__(self, template_file_path, services_data):
        self.template_file_path = template_file_path
        self.services_data = services_data

    def load_template(self):
        with open(self.template_file_path, "r") as template_file:
            self.dockerfile_template = template_file.read()

    def generate_dockerfiles(self):
        root_directory = os.path.dirname(os.path.abspath(__file__))

        for service_info in self.services_data:
            service_name = service_info["name"]
            service_port = service_info["port"]
            directory_name = service_info["directory"]

            dockerfile_content = self.dockerfile_template.replace("<SERVICE_NAME>", directory_name)
            dockerfile_content = dockerfile_content.replace("<SERVICE_PORT>", str(service_port))
            
            # Check if the service name is "client-srv"
            if service_name == "client-srv":
                # Add the "RUN npm run build" instruction
                build_instruction = "RUN npm run build\n"
                dockerfile_content = dockerfile_content.replace("<BUILD>", build_instruction)
            else:
                # Remove the "<BUILD>" placeholder
                dockerfile_content = dockerfile_content.replace("<BUILD>", "")

            file_path = os.path.join(root_directory, directory_name, "Dockerfile")
            
            with open(file_path, "w") as dockerfile:
                dockerfile.write(dockerfile_content)
            print(f"Dockerfile créé pour le service {directory_name}")

        print("Tous les Dockerfiles ont été créés avec succès.")