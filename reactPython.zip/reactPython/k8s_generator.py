# k8s_generator.py
def generate_ingress(routes, service_port):
    paths = [
        f"""
      - path: {route}
        pathType: Prefix
        backend:
          service:
            name: my-service
            port:
              number: {service_port}
    """
        for route in routes
    ]

    ingress = f"""
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: auto-generated-ingress
spec:
  rules:
  - http:
      paths: {"".join(paths)}
    """
    return ingress


def generate_k8s_manifest(service):
    deployment = f"""
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {service['name']}-deployment
  labels:
    app: {service['name']}-deployment
spec:
  replicas: 1
  selector:
    matchLabels:
      app: templates-{service['name']}
  template:
    metadata:
      labels:
        app: templates-{service['name']}
    spec:
      containers:
      - name: {service['name']}-container
        imagePullPolicy: IfNotPresent
        image: {service['name']}
        ports:
        - containerPort: {service['port']}
    """

    service_manifest = f"""
---
apiVersion: v1
kind: Service
metadata:
  name: {service['name']}-srv
spec:
  type: NodePort
  selector:
    app: templates-{service['name']}
  ports:
  - name: {service['name']}-port
    protocol: TCP
    port: {service['port']}
    targetPort: {service['port']}
    """

    return deployment + service_manifest
