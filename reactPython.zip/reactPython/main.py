import os
import yaml
import re
import subprocess
import webbrowser
from dockerfile_generator import DockerfileGenerator
from k8s_generator import generate_k8s_manifest, generate_ingress


def main():
    current_directory = os.path.dirname(os.path.abspath(__file__))
    yaml_file_path = os.path.join(current_directory, "config.yml")

    with open(yaml_file_path, "r") as config_file:
        config_data = yaml.safe_load(config_file)

    services_data = config_data.get("services_data", [])

    user_choice = input("Voulez-vous modifier les paramètres par défaut ? (Oui/Non): ").strip().lower()

    if user_choice == "oui" or user_choice == "o":
        services_data = configure_services()

    dockerfile_generator = DockerfileGenerator("Dockerfile.template", services_data)
    dockerfile_generator.load_template()
    dockerfile_generator.generate_dockerfiles()

    root_directory = os.path.dirname(os.path.abspath(__file__))
    os.makedirs(f"{root_directory}/k8s", exist_ok=True)

    for service in services_data:
        k8s_manifest = generate_k8s_manifest(service)
        k8s_file_path = os.path.join(f"{root_directory}/k8s/", f"{service['name']}_k8s.yaml")
        with open(k8s_file_path, 'w') as k8s_file:
            k8s_file.write(k8s_manifest)

    # Extract routes from all services
    unique_routes = set()
    for service in services_data:
        index_js = os.path.join(current_directory, service['directory'], 'index.js')
        if os.path.exists(index_js):
            routes = extract_routes_from_file(index_js)
            for route in routes:
                if "events" not in route:
                    unique_routes.add((route, service['name'], service['port']))

    # Generate a single ingress.yaml file using unique_routes
    ingress_manifest = generate_ingress_from_unique_routes(unique_routes)
    with open(os.path.join(current_directory, "ingress.yaml"), 'w') as out_file:
        out_file.write(ingress_manifest)


def configure_services():
    services_data = []
    num_services = int(input("Combien de services souhaitez-vous configurer ? "))
    for i in range(num_services):
        service_name = input(f"Nom du service {i + 1}: ").strip()
        service_port = int(input(f"Port pour {service_name}: "))
        directory_name = input(f"Répertoire pour {service_name}: ").strip()
        services_data.append({"name": service_name, "port": service_port, "directory": directory_name})
    return services_data


def extract_routes_from_file(file_path):
    with open(file_path, 'r') as file:
        content = file.read()
        return re.findall(r'app\.\w+\("(/[^"]+)"', content)


def generate_ingress_from_unique_routes(unique_routes):
    ingress_template = {
        "apiVersion": "networking.k8s.io/v1",
        "kind": "Ingress",
        "metadata": {
            "name": "ingress-rules",
            "annotations": {
                "nginx.ingress.kubernetes.io/use-regex": "true"
            },
            "labels": {
                "name": "ingress-red-srv"
            }
        },
        "spec": {
            "rules": [{
                "host": "localhost",
                "http": {
                    "paths": []
                }
            }]
        }
    }

    for route, name, port in unique_routes:
        path_config = {
            "path": route,
            "pathType": "Prefix",
            "backend": {
                "service": {
                    "name": name,
                    "port": {
                        "number": port
                    }
                }
            }
        }
        ingress_template["spec"]["rules"][0]["http"]["paths"].append(path_config)

    return yaml.dump(ingress_template, default_flow_style=False)


def launch_commands_function():
    with open("config.yml", "r") as config_file:
        config_data = yaml.safe_load(config_file)
    
    # Extract the services data from the config
    services_data = config_data.get("services_data", [])

    userdockerhub = "mbenguerraiche"

    # Loop over services data and build Docker images
    # for service_info in services_data:
    #     service_name = service_info["name"]
    #     directory = service_info["directory"]

    #     # Build the Docker image
    #     subprocess.run(["docker", "build", "-t", service_name, f"./{directory}"], check=True)
        
    #     # Tag the Docker image
    #     subprocess.run(["docker", "tag", service_name, f"{userdockerhub}/{service_name}:latest"], check=True)
        
    #     # Push the Docker image
    #     subprocess.run(["docker", "push", f"{userdockerhub}/{service_name}:latest"], check=True)

    # Deploy k8s configurations
    k8s_folder_path = os.path.join(os.getcwd(), "k8s")
    subprocess.run(["kubectl", "apply", "-f", "./k8s"], check=True)
    open_webpage()

def open_webpage():
    webbrowser.open_new(r"http://localhost")

if __name__ == "__main__":
    try:
        main()
        launch_commands_function()
        open_webpage()
    except KeyboardInterrupt:
        print("\nArrêt du programme suite à une interruption du clavier (Ctrl+C).")